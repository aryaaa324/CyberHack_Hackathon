from app.services.fraud_detection import app

if __name__ == "__main__":
    app.run(debug=True)
